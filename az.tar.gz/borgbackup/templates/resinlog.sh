set -ex
echo "collecting resin log files..."
cd {{ webserver_base }}/log
RESINLOG_COLLECT_PATH=/home/tmp/resinlog/resinlog-`date -I`
if [ ! -d $RESINLOG_COLLECT_PATH ]; then
  mkdir -p $RESINLOG_COLLECT_PATH
fi
ls -1 > /tmp/resinlog.ls1
fuser * 2>&1 | cut -d: -f1 | awk -F'/' '{print $NF}' > /tmp/resinlog.awk
comm -23 /tmp/resinlog.ls1 /tmp/resinlog.awk > /tmp/resinlog.comm
mv -t $RESINLOG_COLLECT_PATH  `cat /tmp/resinlog.comm`
