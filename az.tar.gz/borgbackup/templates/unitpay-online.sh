set -ex
echo "collecting unitpay-online trc files..."
UNITPAYONLINETRC_COLLECT_PATH=/home/tmp/trc/unitpay-online-trc-`date +%Y%m -d'60 days ago'`
if [ ! -d $UNITPAYONLINETRC_COLLECT_PATH ]; then
  mkdir -p $UNITPAYONLINETRC_COLLECT_PATH
fi
cd /home/unipay/unitpay-online/trc
mv `date +%Y%m -d'{{ backup_days }} days ago'`* $UNITPAYONLINETRC_COLLECT_PATH
