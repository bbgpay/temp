See [README-windows](./README-windows.md).
